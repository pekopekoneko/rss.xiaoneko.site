<?php
exec('get.py');
echo"finished";
?>